import React from 'react'
import withProtect from '../../utils/withProtect'

function Appointments() {
  return (
    <div>Appointments</div>
  )
}

export default withProtect(Appointments, true)