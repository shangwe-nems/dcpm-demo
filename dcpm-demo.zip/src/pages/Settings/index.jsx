import React from 'react'
import withProtect from '../../utils/withProtect'

function Settings() {
  return (
    <div>Settings</div>
  )
}

export default withProtect(Settings, true)