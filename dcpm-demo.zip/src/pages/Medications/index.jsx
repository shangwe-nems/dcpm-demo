import React from 'react'
import withProtect from '../../utils/withProtect'

function Medications() {
  return (
    <div>Medications</div>
  )
}

export default withProtect(Medications, true)