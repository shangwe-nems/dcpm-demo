import React from 'react'
import withProtect from '../../utils/withProtect'

function Messages() {
  return (
    <div>Messages</div>
  )
}

export default withProtect(Messages, true)