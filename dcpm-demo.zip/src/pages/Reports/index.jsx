import React from 'react'
import withProtect from '../../utils/withProtect'

function Reports() {
  return (
    <div>Reports</div>
  )
}

export default withProtect(Reports, true)