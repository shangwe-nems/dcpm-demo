import React from 'react'

function Footer() {
  return (
    <div style={{color: "#a6a6a6", padding:"0 26px", fontSize:14}}>
        <p> Copyright &#169; {new Date().getFullYear()} DCPM. Tout droits reservés.</p>
    </div>
  )
}

export default Footer